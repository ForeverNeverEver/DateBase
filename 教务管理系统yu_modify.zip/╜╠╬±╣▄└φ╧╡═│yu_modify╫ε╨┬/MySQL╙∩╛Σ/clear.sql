drop table TeacherInfo;
drop table StudentInfo;
drop table AllMessage;
drop table LoginAccount;
drop table PositionList;
drop table DefaultPassword;